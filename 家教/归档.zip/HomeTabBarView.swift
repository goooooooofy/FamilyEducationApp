//
//  HomeTabBarView.swift
//  家教
//
//  Created by goofygao on 15/10/21.
//  Copyright © 2015年 goofyy. All rights reserved.
//

import UIKit

class HomeTabBarView: UIView {

    
     override init(frame: CGRect) {
        super.init(frame: frame)
    }

     required init?(coder aDecoder: NSCoder) {
         fatalError("init(coder:) has not been implemented")
     }

    
    
}
